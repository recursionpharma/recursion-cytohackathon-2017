/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package be.ua.mbarbier.cytohack;

import ij.IJ;
import ij.ImageJ;
import ij.ImagePlus;
import ij.plugin.PlugIn;
import ij.plugin.filter.ParticleAnalyzer;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author mbarbier
 */
public class Challenge_3 implements PlugIn {

	//String projectDir = "C:/Users/mbarbier/Desktop/Cytodata_2017/challenge_3/recursion-cytohackathon-2017-master";
	//String imageDir = projectDir + "/small";
	//String outputDir = projectDir + "/output";
	//String outputMaskDir = projectDir + "/output_mask";
	String imageDir = "C:/Users/mbarbier/Desktop/Cytodata_2017/challenge_3/small";
	String outputDir = "C:/Users/mbarbier/Desktop/Cytodata_2017/challenge_3/output";
	String outputMaskDir = "C:/Users/mbarbier/Desktop/Cytodata_2017/challenge_3/output_mask";
	String projectDir = "C:/Users/mbarbier/Desktop/Cytodata_2017/challenge_3";
	String ilastikDir = "c:/Program Files/ilastik-1.2.2rc4";
	String ilastikPath = ilastikDir + "/" + "run-ilastik.bat";
	String ilastikExt = "tiff";
	
	boolean doClassificationNeuron = true;
	boolean doMaskEnhancementNeuron = true;
	boolean doLabelNuclei = true;
	boolean doClassificationNuclei = true;
	boolean doMaskEnhancementNuclei = true;
	
	public void run_classifier(String imagePath, String outputPath, String ilastikProject) throws IOException {
		Runtime rt = Runtime.getRuntime();
		String cmd = "\""+ilastikPath+"\"" + " --headless --project=" + projectDir + "/" + ilastikProject + " --export_source=\"Simple Segmentation\" --output_format=tiff --output_filename_format=" + outputPath + " " + imagePath;
		//--segmentation_image 
		
		IJ.log(cmd);
		String[] mcmd = {"cmd", "/c", cmd};
		Process pr = rt.exec( mcmd );

		try {
			new Thread(new Runnable() {
				public void run() {
					BufferedReader input = new BufferedReader(new InputStreamReader(pr.getInputStream()));
					String line = null;

					try {
						while ((line = input.readLine()) != null) {
							System.out.println(line);
						}
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}).start();

			pr.waitFor();
		} catch (InterruptedException ex) {
			Logger.getLogger(Challenge_3.class.getName()).log(Level.SEVERE, null, ex);
		}

	}
	
	public ImagePlus maskNeuronEnhance( String imagePath ) {
		ImagePlus imp = IJ.openImage( imagePath );
		imp.getProcessor().invert();
		imp.getProcessor().subtract( (double) 253 );
		imp.getProcessor().medianFilter();
		return imp;
	}

	public ImagePlus maskNucleiEnhance( String imagePath ) {
		ImagePlus imp = IJ.openImage( imagePath );
		imp.getProcessor().invert();
		imp.getProcessor().subtract( (double) 253 );
		imp.getProcessor().medianFilter();
		return imp;
	}
	
	@Override
	public void run(String arg) {
		
	
		//String imagePath = imageDir + "/" + "F02_s10_w3.tif";
		String outputPath = outputDir + "/" + "{nickname}_out.tif";
		String ext = ".tif";
		
		ArrayList< String > fileList = new ArrayList<>();
		ArrayList< String > fileListNuc = new ArrayList<>();
		File folder = new File( imageDir );
		File[] fileArray = folder.listFiles();
		for ( int i = 0; i < fileArray.length; i++ ) {
			String fileName = fileArray[i].getName();
			
			if ( fileName.endsWith("3"+ext) ) {
				fileList.add( fileName );
				IJ.log( fileName );
			}
			if ( fileName.endsWith("1"+ext) ) {
				fileListNuc.add( fileName );
				IJ.log( fileName );
			}
		}
		String imagePath = null;
		
		if ( this.doClassificationNeuron ) {
			for ( String fileName : fileList ) {
				imagePath = imageDir + "/" + fileName;
				try {
					IJ.log("Start classification");
					run_classifier(imagePath, outputPath, "segment_neurons.ilp");
					IJ.log("End classification");
				} catch (IOException ex) {
					Logger.getLogger(Challenge_3.class.getName()).log(Level.SEVERE, null, ex);
				}
			}
		}
		if ( this.doClassificationNuclei ) {
			for ( String fileName : fileListNuc ) {
				imagePath = imageDir + "/" + fileName;
				try {
					IJ.log("Start classification");
					run_classifier(imagePath, outputPath, "segment_nuclei.ilp");
					IJ.log("End classification");
				} catch (IOException ex) {
					Logger.getLogger(Challenge_3.class.getName()).log(Level.SEVERE, null, ex);
				}
			}
		} 
		
		ArrayList< String > fileListMaskNuc = new ArrayList<>();
		ArrayList< String > fileListMask = new ArrayList<>();
		File folderMask = new File( outputDir );
		File[] fileArrayMask = folderMask.listFiles();
		IJ.log( "MaskFiles:" );
			for ( int i = 0; i < fileArrayMask.length; i++ ) {
			String fileName = fileArrayMask[i].getName();
			
			if ( fileName.endsWith("3_out."+ilastikExt) ) {
				fileListMask.add( fileName );
				IJ.log( fileName );
			}
			if ( fileName.endsWith("1_out."+ilastikExt) ) {
				fileListMaskNuc.add( fileName );
				IJ.log( fileName );
			}
		}
	
		
		if ( this.doMaskEnhancementNeuron ) {
			for ( String fileName : fileListMask ) {
				String imageInputPath = outputDir + "/" + fileName;
				String imageMaskPath = outputMaskDir + "/" + fileName;
				ImagePlus mask = maskNeuronEnhance( imageInputPath );
				IJ.save(mask, imageMaskPath);
			}
		}
		
		if ( this.doMaskEnhancementNuclei ) {
			for ( String fileName : fileListMaskNuc ) {
				String imageInputPath = outputDir + "/" + fileName;
				String imageMaskPath = outputMaskDir + "/" + fileName;
				ImagePlus mask = maskNucleiEnhance( imageInputPath );
				IJ.save(mask, imageMaskPath);
				
				if ( this.doLabelNuclei ) {
					ParticleAnalyzer pa = new ParticleAnalyzer();
					//pa.analyze(mask, ip)
				}
			}
		}
		
				
	}
	
	public void test_mask() {
		String outputDir = "C:/Users/mbarbier/Desktop/Cytodata_2017/challenge_3/output";
		String imagePath = outputDir + "/" + "F02_s10_w3_out.tiff";
		ImagePlus maskNeuron = maskNeuronEnhance( imagePath );
	}
	
	public static void main(String[] args) {

        Class<?> clazz = Challenge_3.class;

        System.out.println(clazz.getName());
        String url = clazz.getResource("/" + clazz.getName().replace('.', '/') + ".class").toString();
        String pluginsDir = url.substring(5, url.length() - clazz.getName().length() - 6);
        System.out.println(pluginsDir);
        System.setProperty("plugins.dir", pluginsDir);

        ImageJ imagej = new ImageJ();
		//Challenge_3 c = new Challenge_3();
		//c.test_mask();
		
		IJ.log("START RUN Manual annotation");
		IJ.runPlugIn(clazz.getName(), "");
		IJ.log("END RUN Manual annotation");
	}

}
